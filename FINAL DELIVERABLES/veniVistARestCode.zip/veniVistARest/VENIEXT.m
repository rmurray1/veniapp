saved for Veni project
GT.M 22-APR-2015 16:27:04
VENIEXT
VENIEXT ;RM /VENI DEMO
 ;;
 ; veni checkin routine
 ;
 ; =============================================
 ; notes:
 ;    Logic taken from: VPSRPC4
 ;    data format: DFN_"-"_clinic IEN_"-"_date/timestamp of scheduled appt_";"
 ;    called took check in $$CHECKIN
 ; =============================================
 ;
 Q
 ; =============================================
 ; rpc: gets appointment data
 ; rpcname: VENIEXTRACT
GETDATA(DATA,IEN) ;
 ;
 K VENIARR
 Q:'$D(IEN) "NO DATA"
 D GETS^DIQ(2,IEN_",","1900*","IE","VENIARR")
 S DATA=""
 S C=0
 S DATA(C)=$$GET1^DIQ(2,IEN,.01)
 S RM="" 
 F  S RM=$O(VENIARR(2.98,RM)) Q:RM'>0  D
 . S RM2=""
 . F  S RM2=$O(VENIARR(2.98,RM,RM2)) Q:RM2=""  D
 . . I $D(VENIARR(2.98,RM,.001,"I")) D
 . . . S C=C+1
 . . . ;W !,$G(VENIARR(2.98,RM,.001,"I"))
 . . . I '$D(APPT(RM)) D
 . . . . S APPT(RM)=""
 . . . . ; S DATA(C)=$$FMTHL7^XLFDT($G(VENIARR(2.98,RM,.001,"I")))_"^"_$G(VENIARR(2.98,RM,.01,"E"))
 . . . . S DATA(C)=$$FMTE^XLFDT($G(VENIARR(2.98,RM,.001,"I")))_"^"_$G(VENIARR(2.98,RM,.01,"E"))
 K VENIARR
 Q
 ; =============================================
 ; rpc: check in appointment
 ; rpcName: VENICHECKIN
CHKIN(RESULT,PDFN) ;
 ; 
 S RESULT(0)="0^0"
 Q:'$D(PDFN)
 N DATA
 ;    look appointment for veteran
 S CTIME=$$NOW^XLFDT()
 S FTIME=$$FMADD^XLFDT(CTIME,,1,,)
 S PTIME=$$FMADD^XLFDT(CTIME,,-1,,)
 W !,"Times: "_PTIME_"    : now - "_CTIME_"  f:  "_FTIME
 S RM=$G(DT)
 S CNT=0
 S DATA=""
 F  S RM=$O(^DPT(PDFN,"S",RM)) Q:RM'>0  D
 . W !,PDFN_"  : "_RM
 . I (RM>PTIME)&(RM<FTIME) D
 . . W !,"appointment: "_RM
 . . N DATNOD,CLINIC
 . . S DATNOD=$G(^DPT(PDFN,"S",RM,0))
 . . S VPSCLIN=$P(DATNOD,"^",1)
 . . S VPSDT=RM
 . . S CIEN=$$FIND^SDAM2(PDFN,VPSDT,VPSCLIN)
 . . W !,"VPSCLIN: "_VPSCLIN,?30,"CIEN: "_CIEN
 . . S CLNAM=$$GET1^DIQ(44,VPSCLIN_",",.01)
 . . S RESULT(CNT)=CLNAM_"^"_$$CHECKIN(VPSCLIN,VPSDT,CIEN)
 . . S CNT=CNT+1
 . . S DATA=$G(PDFN)_"-"_$G(CLNAM)_"-"_$G(RM)
 . . W !,"data: "_DATA
 . . Q
 Q
 ;
CHECKIN(CLIN,DTM,CIEN) ;update appropriate fields for check-in (HOSPITAL LOCATION file (#44)
 ;DIE call to actually check patient in
 ; ICR 5791 - update to 44.003,309
 ;Input:
 ; CLIN - clinic ien
 ; DTM - DATE/TIME of appt
 ; CIEN - entry to update with checkin time
 N VPSFDA,VERR,VPSRET
 N %,VPSNOW D NOW^%DTC S VPSNOW=%
 L +^SC(CLIN_",""S"","_DTM):3
 S VPSFDA(44.003,CIEN_","_DTM_","_CLIN_",",309)=VPSNOW  ; PATIENT multiple/APPOINTMENT multiple of HOSPITAL LOCATION file 
 D FILE^DIE("","VPSFDA","VERR")
 L -^SC(CLIN_",""S"","_DTM)
 I $D(VERR) S VPSRET="99-Appt could not be checked in"
 E  S VPSRET=1
 K VPSFDA,VERR
 Q VPSRET
 ; 



