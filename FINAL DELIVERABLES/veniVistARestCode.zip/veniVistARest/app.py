from flask import Flask, url_for
from flask import request
from flask import jsonify
from pyVeniVistA import VistAConn
import json

app = Flask(__name__)

@app.route('/')
def api_root():
    return 'Welcome'

@app.route('/getappt')
def api_getappt():
    if 'ien' in request.args:
        dfn = request.args['ien']
        newconnect = VistAConn(dfn)
        data = newconnect.vcxn()  
        #return 'retreiving patient ' + request.args['ien']
        print("data")
        print(data)
        return data
    else:
        return 'No <ien> param'

@app.route('/hello')
def api_hello():
    if 'name' in request.args:
        return 'Hello ' + request.args['name']
    else:
        return 'Hello Welcome to VeniRest sever'

@app.route('/verifyID')
def api_verifyID():
    if 'id' in request.args:
        vetid = request.args['id']
	check = int(vetid)%2
        if check == 0:
            status = 'status:' + '1'
        else:
            status = 'status:'+ '0'
        print(status)
        return status
    else:
        return 'No <id> param found'

@app.route('/checkin')
def api_checkIN():
    if 'ien' in request.args:
        dfn = request.args['ien']
        data = '0^0'
        try:
            newconnect = VistAConn(dfn)
            data = newconnect.vcxnCheckin()
        except:
            pass

        print("data output:")
        print(data)
        return data
    else:
        return 'No <ien> param'


if __name__ == '__main__':
    app.run(
        host="0.0.0.0",
        port=int("5000"))
