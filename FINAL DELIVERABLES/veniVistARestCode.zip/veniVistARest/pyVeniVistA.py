#!/usr/bin/python
__author__ = 'raleigh.murray@gmail.com'

import sys, getopt
from pyVistABroker.VistaConnection import VistaConnection
from pyVistABroker.RpcParameter import RpcParameter
from pyVistABroker.VistaRpc import VistaRpc
from pyVistABroker.VistaUser import VistaUser
from pyVistABroker.VistaSelect import VistaSelect
from pyVistARpcEx import pyVistARpcEx

'''
    host = 'xxx.dallas.med.va.gov'
    port = 19027
    cxn = VistaConnection(host, port)
    user = VistaUser()
    cxn.connect()
    greeting = user.login(cxn, 'xxxxx', '!xxxx!2', 'R2 MEDIT RPC')
    print(greeting)
    cxn.disconnect()
'''

class VistAConn(object):
    def __init__(self, ien=None, host=None, port=None, contextMenuOption=None):
        self.host = '54.153.26.158'
        self.port = 9430
        self.RpcBrokerContextMenu = 'VENIEXTRACT'
        self.accessCode = 'SM1234'
        self.verifyCode = '!SM1234!!'
        self.ien = ien

    def vcxn(self):
        self.rpcConn = VistaConnection(self.host, self.port)
        user = VistaUser()
        self.rpcConn.connect()
        greeting = user.login( self.rpcConn, self.accessCode, self.verifyCode, 'XWB BROKER EXAMPLE')
        result = 0
        if self.ien is None:
            self.ien = '23'
        try:
            result = pyVistARpcEx.rpc_VeniExt(self.rpcConn, self.ien)
        except:
            pass

        print("VistA Result: ")
        print(result)
        return result

    def vcxnCheckin(self):
        result='0^0'
        if self.ien is None:
            return result

        try:
            self.rpcConn = VistaConnection(self.host, self.port)
            user = VistaUser()
            self.rpcConn.connect()
            greeting = user.login( self.rpcConn, self.accessCode, self.verifyCode, 'XWB BROKER EXAMPLE')
            print("checkin greeting")
            print(greeting)
            result = pyVistARpcEx.rpc_VeniCheckin(self.rpcConn, self.ien)
        except:
            pass
        print("ien: ",self.ien)
        print("VistA Checking result: ")
        print(result)
        return result


def main():
    #  from vavista.rpc import connect, PLiteral, PList, PReference

    ien = None
    host = None
    port = None
    context = None
    access = None
    verify = None

    try:
        opts, args = getopt.getopt(sys.argv[1:], "")
    except getopt.GetoptError:
        print 'pyVeniVista.py dfn\n'
        sys.exit(1)

    if len(args) > 4:
        print(args)
        ien = sys.argv[1]
        host = sys.argv[2]
        port = sys.argv[3]
        context = sys.argv[4]
        access = sys.argv[5]
        verify = sys.argv[6]

    myConnect = VistAConn(ien, host, port, context)
    myConnect.vcxn()


if __name__ == "__main__":
    main()
