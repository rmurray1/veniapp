__author__ = 'Raleigh Murray'

from pyVistABroker.VistaUtils import VistaUtils
from pyVistABroker.RpcParameter import RpcParameter
from pyVistABroker.VistaException import VistaException
from pyVistABroker.VistaRpc import VistaRpc


class pyVistARpcEx(object):

    PREFIX = '[XWB]'
    COUNT_WIDTH = 3
    RPC_VERSION = '1.108'
    EOT = "\x04"

    @staticmethod
    def rpc_r2spl_user_duz(broker):
        if broker.is_connected:
            rpc = VistaRpc.prepare('R2SPL USER DUZ')
            try:
                response = broker.execute(rpc)
                # MURRAY,RALEIGH^18679^INFORMATION TECHNOLOGY SVC^1^11^549^NORTH TEXAS HCS^549
                return response
            except:
                pass
    
    @staticmethod
    def rpc_r2splListUserDocs(broker):
        if broker.is_connected:
            rpc = VistaRpc.prepare('R2SPL LIST USER DOCS')
            try:
                response = broker.execute(rpc)
                print(response)
                return response
            except:
                pass
            
    @staticmethod
    def rpc_VeniExt(broker, ien):
        if broker.is_connected:
            param = [RpcParameter(RpcParameter.LITERAL, ien)]
            rpc = VistaRpc.prepare('VENIEXTRACT', param)
            if ien is not None:    
                try:
                    response = broker.execute(rpc)
                    return response
                except:
                    pass

    @staticmethod
    def rpc_VeniCheckin(broker, ien):
        if broker.is_connected:
            param = [RpcParameter(RpcParameter.LITERAL, ien)]
            rpc = VistaRpc.prepare('VENICHECKIN', param)
            if ien is not None:
                try:
                    response = broker.execute(rpc)
                    return response
                except:
                    pass

